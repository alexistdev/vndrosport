<h3>Aplikasi Marketplace Vndrosport</h3>
<p>Dikembangkan untuk perangkat berbasis android, spesifikasinya diantaranya:<p>
<ul>
  <li>Minimal API adalah 24 - Android 7 Nougat</li>
  <li>Terhubung dengan webservice menggunakan retrofit</li>
  <li>Webservice dengan Codeigniter 3.1</li>
  <li>Database MySQL dan SQLite</li>
</ul>


<p>Cara installasi webservice</p>
<ul>
	 <li>download dari github: $ git clone https://github.com/alexistdev/vndrosport.git</li>
	<li>Letakkan file di directory local anda, biasa di xampp di htdocs</li>
	<li>buka file dan jalankan "composer install" diterminal</p>
	<li>Buat database dan sesuaikan dengan file yang ada di config/database</li>
	<li>import database dari file vndrosport.sql</li>
	<li>login dashboard username: admin password admin</li>
</ul>

